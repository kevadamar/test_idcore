# test_idcore

// note berhubung api create order error, namun ketika jika saya diberi kesempatan untuk memberbaiki saya perbaiki sesuai response api
// saya langsung buat ke waiting payment
// waiting payment 10 detik langsung ke page detail order
