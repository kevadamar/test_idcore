package com.example.test_idcore

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
